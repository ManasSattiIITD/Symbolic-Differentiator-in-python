# The scanning parsing and tokenisation here is done with the help of tree data structure.
# We we create a tree structure with 2 branches storing further operation/variable/constants and the root store the master operation that would be performed on the left and right branches.
# The use of paranthesis is very importatnt here as it help the parser to understand the precedence of operators.
# The precedence should be specified explicitly using paranthesis.
# We can also extend this concept to the compilation/interpretation of programming languages.
# The source code is passed to lexical analyser which generate tokens by removing whitespace and comments, expanding macros and read input.
# The tokens are now parsed by the parser i.e. arranged in a suitable and understandable form according to the programming language rules.
# The parser has a syntax analyser ,sematic analyser and code generator. The code generator are of two types intermediate and machine dependent code generator.
# The interpretor does the work oly till intermediate code generation which is common for all machines.


class expr:

	def __init__(self,S,Nd = None):
		if (Nd):
			self.expr = Nd
		else:
			(e,n) = self.parse(S)
			self.expr = e

	class Node:
		def __init__(self,d):
			self.left = None
			self.right = None
			self.data = d
		
		def toString(self):
			if (self.left and self.right):
				left = self.left.toString()
				right = self.right.toString()
				opr = self.data
				if opr == "+":
					if left == "0.0" or left == "0":
						return "(" +right + ")"
					elif right == "0.0" or right == "0":
						return "(" + left + ")"
					else:
						return "(" + left + " " + opr + " " + right + ")"
				elif opr == "-":
					if left == "0.0" or left == "0":
						return "(" + opr + right + ")"
					elif right == "0.0" or right == "0":
						return "(" + left + ")"
					else:
						return "(" + left + " " + opr + " " + right + ")"
				elif opr == "*":
					if left == "0.0" or right == "0.0" or left == "0" or right=="0":
						return "0.0"
					else:
						return "(" + left + " " + opr + " " + right + ")"
				elif opr == "/":
					if left == "0.0" or left == "0":
						return "0.0"
					elif right == "0.0" or right == "0": 
						Exception("DivisionByZero")
						return
					else:
						return "(" + left + " " + opr + " " + right + ")"
				elif opr == "^":
					if right == "0.0":
						return "(1.0)"
					else:
						return "(" + left + " " + opr + " " + right + ")"
				else:
					return "(" + left + " " + opr + " " + right + ")"
			else:
				return self.data

	def prettyprint(self):
		s = self.expr.toString()
		print(s)
		

	def parse(self,S):
		l = len(S)
		if (S[0] == "("):
			(left,n) =  self.parse(S[1:l-2])
			opr = S[n+1]
			(right,m) = self.parse(S[n+2:l-1])
			expr = self.Node(opr)
			expr.left = left
			expr.right = right
			return (expr,n+m+3)
		elif S[0].isdigit():
			i = 0
			while ((i < l) and (S[i].isdigit() or (S[i] == "."))):
				i = i+1
			num = S[0:i]
			expr = self.Node(num)
			return (expr,i)
		elif S[0].isalpha():
			i = 0
			while ((i < l) and S[i].isalpha()):
				i = i+1
			var = S[0:i]
			expr = self.Node(var)
			return (expr,i)
		else:
			return Exception("Invalid input")

	def constant(self):
		if self.expr.data[0].isdigit():
			return True
		else:
			return False

	def variable(self):
		if self.expr.data[0].isalpha():
			return True
		else:
			return False

	def samevariable(self,x):
		if (self.expr.data == x):
			return True
		else:
			return False

	def sum(self):
		if (self.expr.data == '+'):
			return True
		else:
			return False

	def multiplication(self):
		if self.expr.data == "*":
			return True
		else:
			return False

	def sub(self):
		if self.expr.data == "-":
			return True
		else:
			return False

	def division(self):
		if self.expr.data == "/":
			return True
		else:
			return False

	def exponentiation(self):
		if self.expr.data == "^":
			return True
		else:
			return False

	def addend(self):
		left = self.expr.left
		return expr("",left)

	def augend(self):
		right = self.expr.right
		return expr("",right)

	def makeprod(self,e1,e2,x):
		e = self.Node("+")
		ed1 = e1.deriv(x)
		ed2 = e2.deriv(x)
		if ed1.expr.data == "0.0" or ed1.expr.data == "0":
			e.left = self.Node("0.0")
			e.right = self.Node("*")
			e.right.left = e1.expr
			e.right.right = ed2.expr
		elif ed2.expr.data == "0.0" or ed2.expr.data == "0":
			e.right = self.Node("0.0")
			e.left = self.Node("*")
			e.left.left = e2.expr
			e.left.right = ed1.expr
		else:
			e.left = self.Node("*")
			e.right = self.Node("*")
			e.left.left = e2.expr
			e.left.right = ed1.expr
			e.right.left = e1.expr
			e.right.right = ed2.expr
		return expr("",e)

	def makediv(self,e1,e2,x):
		if e2.expr.data == "0" or e2.expr.data =="0.0":
			Exception("DivisionByZero")
			return
		elif e1.expr.data == "0" or e1.expr.data == "0.0":
			e = self.Node("0.0")
			return e
		else:
			e = self.Node("/")
			e.left = self.Node("-")
			e.right = self.Node("^")
			e.left.left = self.Node("*")
			e.left.right = self.Node("*")
			ed1 = e1.deriv(x)
			ed2 = e2.deriv(x)
			e.left.left.left = e2.expr
			e.left.left.right = ed1.expr
			e.left.right.left = e1.expr
			e.left.right.right = ed2.expr
			e.right.left = e2.expr
			e.right.right = self.Node(str(2.0))
			return expr("",e)

	def makeexpo(self,e1,e2,x):
		if e2.expr.data.isdigit():
			e = self.Node("*")
			e.right = self.Node("*")
			e.right.right = e2.expr
			ed2 = e1.deriv(x)
			e.right.left = ed2.expr
			e.left = self.Node("^")
			e.left.left = e1.expr
			e.left.right = self.Node(str(float(e2.expr.data)-1))
			return expr("",e)
		else:
			e = self.Node("*")
			e.left = self.Node("*")
			e.right = self.Node("^")
			e.right.left = e1.expr
			e.right.right = e2.expr
			ed2 = e2.deriv(x)
			e.left.left = ed2.expr
			e.left.right = self.Node(f"""ln({e1.expr.data})""")
			return expr("",e)

	def makesub(self,e1,e2):
		e = self.Node("-")	
		e.left = e1.expr
		e.right = e2.expr
		return expr("",e)

	def makesum(self,e1,e2):
		e = self.Node("+")	
		e.left = e1.expr
		e.right = e2.expr
		return expr("",e)

	def deriv(self,x):
		if self.constant():
			return expr("0.0")
		if self.variable():
			if self.samevariable(x):
				return expr("1.0")
			else:
				return expr("0.0")
		elif self.sum():
			e1 = self.addend()
			e2 = self.augend()
			return self.makesum(e1.deriv(x),e2.deriv(x))
		elif self.sub():
			e1 = self.addend()
			e2 = self.augend()
			return self.makesub(e1.deriv(x),e2.deriv(x))
		elif self.multiplication():
			e1 = self.addend()
			e2 = self.augend()
			return self.makeprod(e1,e2,x)
		elif self.division():
			e1 = self.addend()
			e2 = self.augend()
			return self.makediv(e1,e2,x)
		elif self.exponentiation():
			e1 = self.addend()
			e2 = self.augend()
			return self.makeexpo(e1,e2,x)
		else:
			raise Exception("DontKnowWhatToDo!")

res = 'Y'			
while res == "Y" or res=="y" :
	b = input("Enter the variable wrt to differentiate: ")
	while not (("a" <= b <= "z") or ("A" <= b <= "Z")) or len(b)!=1 :
		print("Wrong input type !. Please enter again.")
		b = input("Enter the variable wrt to differentiate: ")
	a = input("Enter an expression. Use Paranthesis: ")
	e = expr(a)
	print(f"""The entered expression is: f({b}) = """,end="")
	e.prettyprint()
	print()
	f = e.deriv(b)
	print(f"""The derivative is: f'({b}) = """,end="")
	f.prettyprint()
	print()
	print("*- Do you want to calculate more? Press Y/y for Yes and any other key for No. -*")
	res = input()
	print()


# def precedence(s):
# 	def applybracketsifnot(manas,kaze):
# 		if manas[kaze-2] == "(" and manas[kaze+2]==")" and (not manas[kaze-1].isalpha()) and (not manas[kaze+1].isalpha):
# 			return manas
# 		elif manas[kaze-1].isalpha():
# 			return manas[0:kaze-1]+"("+manas[kaze-1:kaze+2]+")"+manas[kaze+2:]
# 		else:
# 			j=kaze
# 			while j>0 and manas[j]!="(":
# 				j-=1
# 			return manas[0:j]+"("+manas[j:kaze+2]+")"+manas[kaze+2:]

# 	l = len(s)
# 	o=0
# 	c=0
# 	asterisk=0
# 	f_slash=0
# 	plus=0
# 	minus=0
# 	power=0
# 	for i in range(len(s)):
# 		if s[i]=="(":
# 			o+=1
# 		elif s[j]==")":
# 			c+=1
# 	if o!=c:
# 		Exception("UnequalNumberOfParanthesis")
# 		exit()
# 	if s[0] != "(" and s[l-1]!=")":
# 		s="("+s+")"
# 	i=0
# 	while i < len(s):
# 		if s[i] == "/":
# 			f_slash+=1
# 		elif s[i] == "^":
# 			power+=1
# 		elif s[i]=="*":
# 			asterisk+=1
# 		elif s[i]=="+":
# 			plus+=1
# 		elif s[i]=="-":
# 			minus+=1
# 		i+=1
# 	j=0
# 	while j < 5:
# 		arr = ['^','/','*','+','-']
# 		i=0	
# 		while i < len(s):
# 			if s[i] == arr[j]:
# 				s=applybracketsifnot(s,i)
# 				i+=1
# 			i+=1
# 		j+=1			
